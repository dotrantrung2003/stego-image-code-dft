from PIL import Image
import numpy as np
import sys

Q = np.array([
    [16, 11, 14, 14, 18, 24, 49, 72],
    [12, 12, 13, 17, 22, 35, 64, 92],
    [14, 13, 16, 22, 30, 45, 78, 95],
    [14, 17, 22, 29, 45, 50, 105, 110],  # (4,5) = 45
    [18, 22, 30, 45, 55, 85, 130, 130],  # (5,4) = 45
    [24, 35, 45, 55, 85, 120, 145, 140],
    [49, 64, 78, 105, 130, 145, 150, 140],
    [72, 92, 95, 110, 130, 140, 140, 135]
], dtype=np.int32)

block_path = sys.argv[1] # gray_block.txt

block = np.loadtxt(block_path, dtype=np.float64)

block = block - 128

dft_block = np.fft.fft2(block)

real_part = np.real(dft_block)
imag_part = np.imag(dft_block)

real_part = np.round(real_part / Q)
imag_part = np.round(imag_part / Q)

np.savetxt("dft_real.txt", real_part, fmt="%d")
np.savetxt("dft_imag.txt", imag_part, fmt="%d")

print("Real part has been saved in dft_real.txt")
print("Imaginary part part has been saved in dft_imag.txt")

