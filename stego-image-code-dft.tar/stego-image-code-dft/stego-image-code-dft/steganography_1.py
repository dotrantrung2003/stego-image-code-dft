from PIL import Image
import numpy as np
import sys

matrix_path = sys.argv[1] # gray_matrix.txt
gray_matrix = np.loadtxt(matrix_path, dtype=np.float64)
height, width = gray_matrix.shape

pad_h = (8 - height % 8) % 8
pad_w = (8 - width % 8) % 8
gray_padded = np.pad(gray_matrix, ((0, pad_h), (0, pad_w)), mode='constant')
H, W = gray_padded.shape

num_blocks_h = H // 8
num_blocks_w = W // 8

while True:
    try:
        i_block = int(input(f"Row (0 - {num_blocks_h - 1}): "))
        j_block = int(input(f"Col (0 - {num_blocks_w - 1}): "))

        if 0 <= i_block < num_blocks_h and 0 <= j_block < num_blocks_w:
            break
        else:
            print("Invalid!!!\n")
    except ValueError:
        print("Invalid!!!\n")

start_row = i_block * 8
start_col = j_block * 8

gray_block = gray_padded[start_row:start_row+8, start_col:start_col+8]

np.savetxt("gray_block.txt", gray_block, fmt="%d")
print("Gray block has been saved in gray_block.txt")
