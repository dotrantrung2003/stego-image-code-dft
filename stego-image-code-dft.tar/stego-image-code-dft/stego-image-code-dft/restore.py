from PIL import Image
import numpy as np
import sys

matrix_path = sys.argv[1]
gray_matrix = np.loadtxt(matrix_path, dtype=np.float64)

gray_clipped = np.clip(gray_matrix, 0, 255)

gray_uint8 = gray_clipped.astype(np.uint8)

img = Image.fromarray(gray_uint8, mode='L')
image_path = "new_gray_image.png"
img.save(image_path)

print("Image name:", image_path)
width, height = img.size
print(f"Image size: {width} x {height} pixels")
print("New gray image has been saved in new_gray_image.png")
