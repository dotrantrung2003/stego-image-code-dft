from PIL import Image
import numpy as np
import sys

Q = np.array([
    [16, 11, 14, 14, 18, 24, 49, 72],
    [12, 12, 13, 17, 22, 35, 64, 92],
    [14, 13, 16, 22, 30, 45, 78, 95],
    [14, 17, 22, 29, 45, 50, 105, 110],  # (4,5) = 45
    [18, 22, 30, 45, 55, 85, 130, 130],  # (5,4) = 45
    [24, 35, 45, 55, 85, 120, 145, 140],
    [49, 64, 78, 105, 130, 145, 150, 140],
    [72, 92, 95, 110, 130, 140, 140, 135]
], dtype=np.int32)

real_path = sys.argv[1] # dft_real.txt
imag_path = sys.argv[2] # dft_imag.txt

real_part = np.loadtxt(real_path, dtype=np.float64)
imag_part = np.loadtxt(imag_path, dtype=np.float64)

real_part = real_part * Q
imag_part = imag_part * Q

dft_block = real_part + 1j * imag_part

idft_block = np.fft.ifft2(dft_block)

real_block = np.real(idft_block)
rounded_block = np.round(real_block + 128)

np.savetxt("new_gray_block.txt", rounded_block, fmt="%d")
print("New gray block has been saved in new_gray_block.txt")